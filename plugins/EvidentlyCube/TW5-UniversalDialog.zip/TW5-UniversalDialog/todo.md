* Enter to select
* Escape to cancel
* Unfocus to cancel
* Support params