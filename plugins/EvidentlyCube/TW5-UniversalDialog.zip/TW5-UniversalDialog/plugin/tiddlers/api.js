/*\
title: $:/plugins/EvidentlyCube/UniversalDialog/api.js
type: application/javascript
module-type: library

API for the universal dialog

\*/
(function () {
	"use strict";

	const STATE_TIDDLER = "$:/temp/UniversalDialog/state";
	const DEFAULT_ACTION = '<$action-navigate $to=<<title>> $scroll="yes" />'
		+ '<$action-sendmessage $message="tm-ec-ud-action" $param="close" />';
	const NavigatorWidget = require('$:/core/modules/widgets/navigator.js').navigator;
	const ResultStore = require('$:/plugins/EvidentlyCube/UniversalDialog/result-store.js').ResultStore;

	function UniversalDialog() {
		this.rulesets = [];
		this.currentRuleset = null;
		this.query = "";

		$tw.rootWidget.addEventListener('tm-ec-ud-action', this.handleMessage.bind(this));
	};

	UniversalDialog.prototype.handleMessage = function(e) {
		console.log(e);

		switch (e.param) {
			case 'next-result':
				ResultStore.changeSelectedIndex(1);
				break;
			case 'prev-result':
				ResultStore.changeSelectedIndex(-1);
				break;
			case 'select-option':
				const selectedIndex = e.paramObject.index || ResultStore.getSelectedIndex();
				const result = ResultStore.getStoredResultAt(selectedIndex - 1);
				const widget = findNavigateWidget() || $tw.rootWidget;
				widget.invokeActionString(
					this.currentRuleset.selectAction,
					e.widget,
					e.event,
					{index: result.index, title: result.title}
				);
				break;
			case 'set-query':
				$tw.wiki.setText(STATE_TIDDLER, 'text', null, e.paramObject.query || "");
				this.handleInput(null);
				break;
			case 'input':
				this.handleInput(e.event);
				break;
			case 'close':
				$tw.wiki.setText(STATE_TIDDLER, 'is-open', null, undefined);
				break;

			case 'open':
				this._updateRulesetList(this._getRulesetTiddlerList());

				this.currentRuleset = this.findRuleset("");

				$tw.wiki.setText(STATE_TIDDLER, 'is-open', null, 1);
				$tw.wiki.setText(STATE_TIDDLER, 'text', null, "");
				$tw.wiki.setText(STATE_TIDDLER, 'prefix', null, "");
				$tw.wiki.setText(STATE_TIDDLER, 'limit', null, "11");
				$tw.wiki.setText(STATE_TIDDLER, 'selected', null, "1");
				this.refreshResults();
				break;
		}
	};

	UniversalDialog.prototype.handleInput = function(e) {
		this.query = $tw.wiki.getTiddlerText(STATE_TIDDLER);
		this.currentRuleset = this.findRuleset(this.query) || this.currentRuleset;
		this.refreshResults();
	};

	UniversalDialog.prototype.refreshResults = function() {
		if (!this.currentRuleset) {
			return;
		}

		const encodedResults = [];
		const resultsSet = new Set();
		const addStepResults = function(results, step) {
			for (const result of results) {
				if (resultsSet.has(result)) {
					continue;
				}

				encodedResults.push(ResultStore.encodeResultRow(encodedResults.length + 1, result, step.hint));
				resultsSet.add(result);
			}
		}
		const baseQuery = this.currentRuleset.excludePrefix
			? this.query.substring(this.currentRuleset.prefix.length)
			: this.query;

		for (const step of this.currentRuleset.steps) {
			const query = baseQuery;
			// Todo add query transform step
			const stepResults = $tw.wiki.filterTiddlers(step['results-filter'] || query, getVariablesFauxWidget({query: query}));

			addStepResults(stepResults, step);
		}

		ResultStore.storeResults(encodedResults);
	};

	UniversalDialog.prototype.findRuleset = function(prefix) {
		prefix = prefix || "";
		for (const ruleset of this.rulesets) {
			const rulesetPrefix = ruleset.prefix || "";

			if (rulesetPrefix === prefix) {
				return ruleset;
			}
		}

		return null;
	}

	UniversalDialog.prototype._getCurrentState = function() {
		const tiddler = $tw.wiki.getTiddler(STATE_TIDDLER);

		return tiddler ? tiddler.fields : {
			'is-open': false,
			text: '',
			prefix: '',
			limit: 0,
			selected: 1,
			results: '',
			'results-count': 0
		}
	}
	UniversalDialog.prototype._getRulesetTiddlerList = function () {
		return $tw.wiki.getTiddlersWithTag("$:/tags/EC/UniversalDialog/Ruleset");
	};

	UniversalDialog.prototype._getRulesetSteps = function(rulesetTitle) {
		return $tw.wiki.filterTiddlers(
			"[all[tiddlers]tag[$:/tags/EC/UniversalDialog/Step]!is[draft]field:parent<parent>]",
			getVariablesFauxWidget({parent: rulesetTitle})
		);
	}

	UniversalDialog.prototype._updateRulesetList = function(tiddlerList) {
		for (var i = 0; i < tiddlerList.length; i++) {
			var title = tiddlerList[i];
			var tiddlerFields = $tw.wiki.getTiddler(title).fields;

			this.rulesets.push({
				prefix: tiddlerFields.prefix || "",
				selectAction: tiddlerFields.actions || DEFAULT_ACTION,
				excludePrefix: tiddlerFields['exclude-prefix'] === '1',
				steps: this._getRulesetSteps(title).map(function(title) {
					return $tw.wiki.getTiddler(title).fields;
				})
			});
		}
	}

	function getVariablesFauxWidget(vars) {
		return {
			getVariable: function (name) {
				return vars[name] || "";
			}
		}
	}

	function findNavigateWidget() {
		const widgets = [$tw.rootWidget];
		while (widgets.length > 0) {
			const widget = widgets.shift();

			if (widget instanceof NavigatorWidget) {
				return widget;
			}

			widgets.push.apply(widgets, widget.children);
		}

		return null;
	}

	exports.UniversalDialog = UniversalDialog;
})();
